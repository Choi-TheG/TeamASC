$(document).ready(function() {
	console.log('success');
				
	$('.newPw').on('change', function() {
		let pw1 = $("#newPw1").val();
		let pw2 = $("#newPw2").val();
					
		if(pw1 != "" || pw2 != "") {
			if(pw2 === "") {
				$("#ckNewPwd2").html('');
			} else if(pw1 == pw2) {
				$("#ckNewPwd2").html('일치');
				$("#ckNewPwd2").attr('color', 'green');
			} else {
				$("#ckNewPwd2").html('비밀번호가 일치하지 않습니다.');
				$("#ckNewPwd2").attr('color', 'red');
			} 
		}
					
	}); // newPw end
				
	$('#updateInfoForm').submit(function() { // submit 버튼 클릭 시 발동, 비밀번호가 일치해야 수정 가능
		let pw1 = $("#newPw1").val();
		let pw2 = $("#newPw2").val();
					
		if(pw1 != pw2) {
			alert("비밀번호가 일치하지 않습니다.");
			return false;
		} else {
			alert("수정 완료");
		}
					
	}); // updateInfoForm end
	
		$("#newPw1").on("change", function() {
		var newPw = $("#newPw1").val();
		var id = $("#id").val();
		
		var reg = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[?!@$%&]).{8,}$/;
		var hangulCk = /[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]/;
		
		if(false === reg.test(newPw)) {
			$("#ckNewPwd1").html('비밀번호는 최소 8자 이상, 대문자/소문자/숫자/특수문자(?,!,@,$,%,&)를 모두 포함해야 합니다.');
			$("#ckNewPwd1").attr('color', 'gray');
			
		} else if(/(\w)\1\1\1/.test(newPw)) {
			alert("같은 문자를 4번 이상 사용하실 수 없습니다.");
			return false;
			
		} else if(newPw.search(id) > -1) {
			alert("비밀번호에 아이디가 포함되어 있습니다.");
			return false;
			
		} else if(newPw.search(/\s/) != -1) {
			alert("비밀번호는 공백 없이 입력해주세요.");
			return false;
			
		} else if(hangulCk.test(newPw)) {
			alert("비밀번호에는 한글을 사용할 수 없습니다.");
			return false;
			
		} else {
			$("#ckNewPwd1").html('사용가능한 비밀번호입니다.');
			$("#ckNewPwd1").attr('color', 'green');
			console.log("success");
		}
		
	}); // newPw1 end
				
}); // document end
	