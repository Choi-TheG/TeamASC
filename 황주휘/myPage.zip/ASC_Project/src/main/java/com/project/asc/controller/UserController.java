package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.UserService;
import com.project.asc.vo.UserVO;

@RequestMapping("/user")
@Controller("userController")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	/* 개인정보 수정 */
	@RequestMapping(value="/updateMyInfo", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView updateMyInfo(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pwd = request.getParameter("newPwd2");
		String pwdOld = request.getParameter("pwd");
		String email = request.getParameter("email");
		String phoneNum = request.getParameter("phoneNum");
		
		if(pwd == "") {
			user.setName(name);
			user.setEmail(email);
			user.setPhoneNum(phoneNum);
			user.setPwd(pwdOld);
			System.out.println(user);
		} else {
			user.setName(name);
			user.setPwd(pwd);
			user.setEmail(email);
			user.setPhoneNum(phoneNum);
			System.out.println("pwd2");
		}
		
		flag = userService.updateMyInfo(user); 
		
		if(flag) {
			mav.addObject("user", user);
			System.out.println("수정 완료");
		}
		
		System.out.println(user);
		mav.setViewName("redirect:/user/viewMyPage?id=" + id);
		return mav;
	}
	
	/* 비밀번호 체크 */
	@RequestMapping(value="/pwdCheck", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView pwdCheck(@RequestParam("pwd") String pwd, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		UserVO user = userService.selectUserPwd(pwd);
		String viewName = "/updateMyPage";
		
		boolean ckPwd = false;
		if (user != null) {
			request.getSession().setAttribute(pwd, user);
			ckPwd = true;
		} else {
			viewName = "/pwdCheckPage";
		}
		
		System.out.println(ckPwd);
		request.getSession().setAttribute("ckPwd", ckPwd);
		mav.setViewName(viewName);
		return mav;
	}
	
	/* 비밀번호 체크 페이지 */
	@RequestMapping(value="/pwdCheckPage", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView pwdCheckPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/pwdCheckPage");
		return mav;
	}
	
	/* 마이페이지 보기 */
	@RequestMapping(value="/viewMyPage", method= {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView viewMyPage(@RequestParam(required = false) String id, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		System.out.println("controller seq = " + id);
		UserVO user = userService.selectMyInfo(id);
	
		mav.addObject("member",user);
		mav.setViewName("/viewMyPage");
		return mav;
	}
	
	@RequestMapping(value="/main", method=RequestMethod.GET)
	public ModelAndView main(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/main");
		return mav;
	}
	
	@RequestMapping(value="/createProject", method=RequestMethod.GET)
	public ModelAndView createProject(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/createProject");
		return mav;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	@RequestMapping(value = "/viewLogin", method = RequestMethod.GET)
	public ModelAndView viewLogin(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewLogin";
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam("id") String id, @RequestParam("pwd") String pwd, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/main";

		UserVO user = userService.selectUser(id,pwd);
		//System.out.println(user);
		boolean isLogon = false;
		if (user != null) {
			request.getSession().setAttribute("member", user);
			isLogon = true;
		} else {
			viewName = "/viewLogin";
			System.out.println("login");
		}
		System.out.println(isLogon);
		
		request.getSession().setAttribute("isLogon", isLogon);
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/logout", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/main";
		request.getSession().invalidate();
		mav.setViewName(viewName);
		return mav;
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView selectUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		String viewName = "user";
		ArrayList<UserVO> list = userService.selectUser();
		mav.addObject("list",list);
		
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/viewJoinPage",method=RequestMethod.GET)
	public ModelAndView createUserPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		String viewName = "/user/viewJoinPage";
		
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/createUser",method=RequestMethod.POST)
	public ModelAndView createUser(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		
		flag = userService.inserUser(user);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/main";
		} 
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView deleteUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		int seq = Integer.parseInt(request.getParameter("seq"));
		flag = userService.deleteUser(seq);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/user/list";
		} 
		mav.setViewName(viewName);
		
		return mav;
	}
}
