package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.ManagerService;
import com.project.asc.vo.UserVO;

@RequestMapping("/manager")
@Controller("managerController")
public class ManagerController {

	@Autowired
	private ManagerService managerService;
	
	/* 검색 */
	@RequestMapping(value = "/searchUser", method = RequestMethod.POST)
	public ModelAndView searchUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		String word = request.getParameter("searchUser");
		
		ArrayList<UserVO> list = new ArrayList<UserVO>();
		list = managerService.searchUserList(word);
		
		System.out.println("search: " + word);
		mav.addObject("list", list);
		mav.setViewName("redirect:/manager/viewUserList");
		return mav;
	}
	
	/* 상태(status) 'N'으로 바꾸기 */
	@RequestMapping(value = "/updateUserStatus", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView updateUserStatus(@RequestParam("userSeq") int userSeq, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		
		flag = managerService.updateUserStatus(userSeq);
		
		System.out.println("delete success");
		mav.setViewName("redirect:/manager/viewUserList");
		return mav;
	}
	
	/* 회원정보 수정 */
	@RequestMapping(value = "/updateUserInfo", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView updateUserInfo(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		
		int userSeq = Integer.parseInt(request.getParameter("userSeq").trim());
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phoneNum = request.getParameter("phoneNum");
		String joinDate = request.getParameter("joinDate");
		String status = request.getParameter("status");
		
		user.setUserSeq(userSeq);
		user.setId(id);
		user.setPwd(pwd);
		user.setName(name);
		user.setEmail(email);
		user.setPhoneNum(phoneNum);
		user.setJoinDate(joinDate);
		user.setStatus(status);
		
		System.out.println(user);
		flag = managerService.updateUserInfo(user);
		
		if(flag) {
			mav.addObject("user", user);
			System.out.println("userSeq = " + userSeq);
		}
		
		System.out.println("updateController");
		mav.setViewName("redirect:/manager/viewUserProfile?userSeq=" + userSeq);
		return mav;
	}
	
	/* 회원 상세정보 페이지 가기 */
	@RequestMapping(value = "/viewUserProfile", method = RequestMethod.GET)
	public ModelAndView viewUserProfile(@RequestParam("userSeq") int userSeq, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		String viewName = "/userProfile";
		UserVO user = managerService.selectUserInfo(userSeq);
		
		mav.addObject("member", user);
		mav.setViewName(viewName);
		return mav;
	}
	
	/* 전체 회원 목록 불러오기 */
	@RequestMapping(value = "/viewUserList", method = RequestMethod.GET)
	public ModelAndView viewUserList(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		String viewName = "/userList";
		
		ArrayList<UserVO> list = managerService.selectAll();
		
		mav.addObject("list", list);
		mav.setViewName(viewName);
		return mav;
	}
	
	/* 관리자 페이지  */
	@RequestMapping(value = "/viewManagerPage", method = RequestMethod.GET)
	public ModelAndView viewManagerPage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		String viewName = "/managerPage";
		
		System.out.println(viewName);
		mav.setViewName(viewName);
		return mav;
	}
}
