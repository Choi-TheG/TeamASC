package com.project.asc.vo;

public class DocVO {
	private int docSeq;
	private int projectSeq;
	private String docName;
	private String docItem1;
	private String docItem2;
	private String docItem3;
	private String docItem4;
	private String docItem5;
	private String docContent1;
	private String docContent2;
	private String docContent3;
	private String docContent4;
	private String docContent5;
	private String createDate;
	
	
	
	public DocVO() {
		super();
	}

	public DocVO(int docSeq, int projectSeq, String docName, String docItem1, String docItem2, String docItem3,
			String docItem4, String docItem5, String docContent1, String docContent2, String docContent3,
			String docContent4, String docContent5, String createDate) {
		super();
		this.docSeq = docSeq;
		this.projectSeq = projectSeq;
		this.docName = docName;
		this.docItem1 = docItem1;
		this.docItem2 = docItem2;
		this.docItem3 = docItem3;
		this.docItem4 = docItem4;
		this.docItem5 = docItem5;
		this.docContent1 = docContent1;
		this.docContent2 = docContent2;
		this.docContent3 = docContent3;
		this.docContent4 = docContent4;
		this.docContent5 = docContent5;
		this.createDate = createDate;
	}
	

	public int getDocSeq() {
		return docSeq;
	}
	public void setDocSeq(int docSeq) {
		this.docSeq = docSeq;
	}
	public int getProjectSeq() {
		return projectSeq;
	}
	public void setProjectSeq(int projectSeq) {
		this.projectSeq = projectSeq;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocItem1() {
		return docItem1;
	}
	public void setDocItem1(String docItem1) {
		this.docItem1 = docItem1;
	}
	public String getDocItem2() {
		return docItem2;
	}
	public void setDocItem2(String docItem2) {
		this.docItem2 = docItem2;
	}
	public String getDocItem3() {
		return docItem3;
	}
	public void setDocItem3(String docItem3) {
		this.docItem3 = docItem3;
	}
	public String getDocItem4() {
		return docItem4;
	}
	public void setDocItem4(String docItem4) {
		this.docItem4 = docItem4;
	}
	public String getDocItem5() {
		return docItem5;
	}
	public void setDocItem5(String docItem5) {
		this.docItem5 = docItem5;
	}
	public String getDocContent1() {
		return docContent1;
	}
	public void setDocContent1(String docContent1) {
		this.docContent1 = docContent1;
	}
	public String getDocContent2() {
		return docContent2;
	}
	public void setDocContent2(String docContent2) {
		this.docContent2 = docContent2;
	}
	public String getDocContent3() {
		return docContent3;
	}
	public void setDocContent3(String docContent3) {
		this.docContent3 = docContent3;
	}
	public String getDocContent4() {
		return docContent4;
	}
	public void setDocContent4(String docContent4) {
		this.docContent4 = docContent4;
	}
	public String getDocContent5() {
		return docContent5;
	}
	public void setDocContent5(String docContent5) {
		this.docContent5 = docContent5;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	@Override
	public String toString() {
		return "DocVO [docSeq=" + docSeq + ", projectSeq=" + projectSeq + ", docName=" + docName + ", docItem1="
				+ docItem1 + ", docItem2=" + docItem2 + ", docItem3=" + docItem3 + ", docItem4=" + docItem4
				+ ", docItem5=" + docItem5 + ", docContent1=" + docContent1 + ", docContent2=" + docContent2
				+ ", docContent3=" + docContent3 + ", docContent4=" + docContent4 + ", docContent5=" + docContent5
				+ ", createDate=" + createDate + "]";
	}
}
