package com.project.asc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.UserDAO;
import com.project.asc.vo.UserVO;

@Service("userService")
public class UserService {
	
	@Autowired
	private UserDAO userDAO;
	
	public ArrayList<UserVO> selectUser() {
		ArrayList<UserVO> list = null;
		
		list = userDAO.selectUser();
		
		return list;
	}
	
	public boolean inserUser(UserVO user) {
		boolean flag = false;
		
		flag = userDAO.InsertUser(user);
		
		return flag;
	}
	
	public boolean deleteUser(int seq) {
		boolean flag = false;
		
		flag = userDAO.deleteUser(seq);
		
		return flag;
	}
}
