package com.project.asc.dao;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("testDAO")
public class TestDAO {
	@Autowired
	private SqlSession sqlSession;
	
	public boolean testDB() throws SQLException {
		boolean flag = false;
		Connection con = sqlSession.getConnection();
		if(con!=null) {
			flag = true;
			con.close();
		}
		return flag;
	}
}
