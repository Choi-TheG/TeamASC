package asc.project.refactory.vo;

public class MemberVO {

}
