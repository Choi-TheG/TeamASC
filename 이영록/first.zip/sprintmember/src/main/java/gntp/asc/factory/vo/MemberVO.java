package gntp.asc.factory.vo;

public class MemberVO {

}
