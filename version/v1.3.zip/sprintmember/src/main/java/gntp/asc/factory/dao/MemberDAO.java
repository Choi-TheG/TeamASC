package gntp.asc.factory.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gntp.asc.factory.vo.MemberVO;

@Repository("MemberDAO")
public class MemberDAO {
	
	@Autowired
	private SqlSession sqlSession;
	
	public MemberVO selectMemberOne(String memberNo) throws SQLException {
		MemberVO member = null;
		
		member = sqlSession.selectOne("selectMemberById",memberNo);
		
		return member;
	}
	
	public MemberVO checkMember(MemberVO vo) throws SQLException {
		MemberVO member = null;
		
		member = sqlSession.selectOne("selectMemberByIdAndPwd",vo);
		
		return member;
	}
	
	public ArrayList<MemberVO> selectMemberList() throws SQLException {
		ArrayList<MemberVO> list = null;
		
		list = (ArrayList) sqlSession.selectList("selectMemberList");
		
		return list;
	}
	
	public ArrayList<MemberVO> searchMemberList(String word) throws SQLException {
		ArrayList<MemberVO> list = null;
		
		list = (ArrayList) sqlSession.selectList("searchMemberList",word);
		
		return list;
	}
	
	public boolean insertMember(MemberVO vo) throws SQLException {
		boolean flag = false;
		
		MemberVO maxVO = sqlSession.selectOne("selectMemberMax");
		String maxId = null;
		if(maxVO == null) {
			maxId = "20220001";
		} else {
			maxId = String.valueOf(Integer.parseInt(maxVO.getMemberNo()) + 1);
		}
		
		vo.setMemberNo(maxId);
		
		int affectedCount = sqlSession.insert("insertMember", vo);
		
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	public boolean updateMember(MemberVO vo) throws SQLException {
		boolean flag = false;
		
		int affectedCount = sqlSession.update("updateMember", vo);
		
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	public boolean leaveMember(MemberVO vo) throws SQLException {
		boolean flag = false;
		
		int affectedCount = sqlSession.update("leaveMember", vo);
		
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	public boolean deleteMember(String memberNo) throws SQLException {
		boolean flag = false;
		
		int affectedCount = sqlSession.delete("deleteMember", memberNo);
		
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
}
