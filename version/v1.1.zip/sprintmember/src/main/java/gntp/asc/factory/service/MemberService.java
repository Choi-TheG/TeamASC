package gntp.asc.factory.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gntp.asc.factory.dao.MemberDAO;
import gntp.asc.factory.vo.MemberVO;

@Service("memberService")
public class MemberService {
	
	@Autowired
	private MemberDAO memberDAO;

	public boolean joinMember(MemberVO member) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag  = memberDAO.insertMember(member);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
	}

	public MemberVO readMember(String memberNo) {
		// TODO Auto-generated method stub
		MemberVO member = new MemberVO();
		try {
			member = memberDAO.selectMemberOne(memberNo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return member;
	}
	
	public ArrayList<MemberVO> allMember() {
		ArrayList<MemberVO> list = new ArrayList<MemberVO>();
		try {
			list = memberDAO.selectMemberList();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(list==null) {
			System.out.println("list는 null");
		}
		return list;
	}
	
	public ArrayList<MemberVO> searchMember(String word) {
		ArrayList<MemberVO> list = new ArrayList<MemberVO>();
		try {
			list = memberDAO.searchMemberList(word);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(list==null) {
			System.out.println("list는 null");
		}
		return list;
	}
	
	public MemberVO checkMember(String memberNo,String pwd) {
		
		MemberVO member = new MemberVO();
		member.setMemberNo(Integer.parseInt(memberNo));
		member.setPwd(pwd);
		
		MemberVO vo = null;
		try {
			vo = memberDAO.checkMember(member);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return vo;
	}

	public MemberVO oneMember(String memberNo) {
		MemberVO member = new MemberVO();
		try {
			member = memberDAO.selectMemberOne(memberNo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(member==null) {
			System.out.println("member는 null");
		}
		return member;
	}

	public boolean updateMember(MemberVO member) {
		boolean flag = false;
		try {
			flag = memberDAO.updateMember(member);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!flag) {
			System.out.println("update실패");
		}
		return flag;
	}
	
	public boolean leaveMember(String memberNo) {
		boolean flag = false;
		MemberVO vo = new MemberVO();
		vo.setMemberNo(Integer.parseInt(memberNo));
		vo.setWork_yn("N");
		try {
			flag = memberDAO.leaveMember(vo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!flag) {
			System.out.println("퇴사실패");
		}
		return flag;
	}
	
	public boolean deleteOne(String memberNo) {
		boolean flag = false;
		try {
			flag = memberDAO.deleteMember(memberNo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}


}