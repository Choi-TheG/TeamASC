package com.project.asc.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.asc.vo.ProjectVO;
import com.project.asc.vo.UserVO;

@Repository("managerDAO")
public class ManagerDAO {
	
	@Autowired
	private SqlSession sqlSession;
	
	/* 검색 */
	public ArrayList<UserVO> searchUserList(String word) {
		ArrayList<UserVO> list = null;
		
		list = (ArrayList)sqlSession.selectList("mapper.user.searchUserList", word);
		
		return list;
	}
	
	/* 상태(status) 'N'으로 바꾸기 */
	public boolean updateUserStatus(int seq) {
		boolean flag = false;
		
		int affectedCount = sqlSession.update("mapper.user.updateUserStatus", seq);
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	/* 회원정보 수정 */
	public boolean updateUserInfo(UserVO user) {
		boolean flag = false;
		
		int affectedCount = sqlSession.update("mapper.user.updateUserInfo", user);
		if(affectedCount > 0) {
			flag = true;
		}
		
//		System.out.println("updateDAO");
		return flag;
	}
	
	/* 회원 상세정보 페이지 가기 */
	public UserVO selectUserInfo(int seq) {
		UserVO user = null;
		user = sqlSession.selectOne("mapper.user.selectUserInfo", seq);
		
		return user;
	}
	
	/* 전체 회원 목록 불러오기 */
	public ArrayList<UserVO> selectAll() {
		ArrayList<UserVO> list = null;
		
		list = (ArrayList)sqlSession.selectList("mapper.user.selectAllUserList");
		
		return list;
	}

	public ArrayList<ProjectVO> selectProjectAll() {
		ArrayList<ProjectVO> list = null;
		
		list = (ArrayList) sqlSession.selectList("mapper.project.selectProjectAll");
		
		return list;
	}
}
