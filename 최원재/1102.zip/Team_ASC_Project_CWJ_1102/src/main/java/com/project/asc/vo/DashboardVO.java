package com.project.asc.vo;

import java.util.ArrayList;

public class DashboardVO {
	private ArrayList<DocumentsVO> docList;
	
	public ArrayList<DocumentsVO> getDocList(){
		return docList;
	}
	
	public void setDocList(ArrayList<DocumentsVO> docList) {
		this.docList = docList;
	}
}
