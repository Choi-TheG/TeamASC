package com.project.asc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.DocumentsDAO;
import com.project.asc.vo.DocumentsVO;

@Service("documentsService")
public class DocumentsService {
	@Autowired
	private DocumentsDAO documentsDAO;
	
	public DocumentsVO readPlan(String projectSeq) {
		DocumentsVO documents = null;
		documents = documentsDAO.selectDocuments(projectSeq);
		
		return documents;
	}
	
	public DocumentsVO viewUpdatePlan(String documentsSeq) {
		DocumentsVO documents = null;
		documents = documentsDAO.viewUpdateDocuments(documentsSeq);
		
		return documents;
	}
	
	public boolean updatePlan(DocumentsVO documents) {
		boolean flag = false;
		documentsDAO.updateDocuments(documents);
		if(documentsDAO.updateDocuments(documents)) {
			flag = true;
		}
		return flag;
	}
	
	public boolean deletePlan(DocumentsVO documents) {
		boolean flag = false;
		documentsDAO.deleteDocuments(documents);
		if(documentsDAO.deleteDocuments(documents)) {
			flag = true;
		}
		return flag;
	}
}
