package com.project.asc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.UserService;
import com.project.asc.vo.UserVO;
@ResponseBody
@RequestMapping("/user")
@RestController("userController")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value = "/viewLoginPage", method = RequestMethod.GET)
	public ModelAndView viewLogin(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/user/viewLoginPage";
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value = "/viewLogionBeforeProject", method = RequestMethod.GET)
	public ModelAndView viewLogionBeforeProject(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/user/viewLoginPage";
		mav.addObject("projectYN","Y");
		mav.setViewName(viewName);
		return mav;
	}
	
	//rest 로그인 체크
	@RequestMapping(value="/checkIdPwd",method=RequestMethod.GET)
	public boolean checkUserIdPwd(@RequestParam("userId") String userId,@RequestParam("userPwd") String userPwd, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		boolean flag = false;
		flag = userService.checkId(userId,userPwd);
		return flag;
	}
	
	//rest 아이디 중복 체크
	@RequestMapping(value="/checkId",method=RequestMethod.GET)
	public boolean checkUserId(@RequestParam("userId") String userId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean flag = false;
		flag = userService.checkId(userId);
		return flag;
	}
		
	@RequestMapping(value = "/login", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView login(@RequestParam("id") String id, @RequestParam("pwd") String pwd,@RequestParam("projectYN") String projectYN, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "redirect:/main";

		UserVO user = userService.selectUser(id,pwd);
		boolean isLogon = false;
		if (user != null) {
			request.getSession().setAttribute("member", user);
			isLogon = true;
			
			if(projectYN.equals("Y")) {
				viewName = "redirect:/project/createProjectPage";
			}
		} else {
			viewName = "/user/viewLoginPage";
		}
		
		request.getSession().setAttribute("isLogon", isLogon);

		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/logout", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "redirect:/main";
		request.getSession().invalidate();
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/viewJoinPage",method=RequestMethod.GET)
	public ModelAndView createUserPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		String viewName = "/user/viewJoinPage";
		
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/createUser",method=RequestMethod.POST)
	public ModelAndView createUser(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		System.out.println(user.getEmail());
		flag = userService.inserUser(user);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/main";
		} 
		mav.setViewName(viewName);
		
		return mav;
	}
	
	//아이디 찾기 페이지
		@RequestMapping(value = "/viewFindInfo", method = RequestMethod.GET)
		public ModelAndView viewFindInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
			ModelAndView mav = new ModelAndView();
			String viewName = "/viewFindInfo";
			//System.out.println("findInfo");
			mav.setViewName(viewName);
			return mav;
		}
		
		//아이디 찾기
		@RequestMapping(value = "/findInfoId", method = {RequestMethod.GET,RequestMethod.POST})
		public ModelAndView findInfoId(@RequestParam("name") String name, @RequestParam("email") String email, HttpServletRequest request, HttpServletResponse response) throws Exception {
			ModelAndView mav = new ModelAndView();
			String viewName = "/error";
			UserVO user = new UserVO();
			user.setName(name);
			user.setEmail(email);
			
			String id = userService.findId(user);
			
			if (id != null) {
				request.getSession().setAttribute("id", id);
				viewName = "/viewId";
			} 
			request.getSession().setAttribute("id", id);
			mav.setViewName(viewName);
			return mav;
		}
		
		//비번찾기 페이지
		@RequestMapping(value = "/findInfoPwd", method = {RequestMethod.GET,RequestMethod.POST})
		public ModelAndView findInfoPwd(@RequestParam("id") String id, @RequestParam("name") String name, @RequestParam("email") String email, HttpServletRequest request, HttpServletResponse response) throws Exception {
			ModelAndView mav = new ModelAndView();
			String viewName = "/error";
			UserVO user = new UserVO();
			user.setId(id);
			user.setName(name);
			user.setEmail(email);
			
			String pwd = userService.findPwd(user);
			
			if (pwd != null) {
				request.getSession().setAttribute("user", user);
				viewName = "/updatePwd";
			} 
			mav.setViewName(viewName);
			return mav;
		}
		
		//비밀번호 새로 설정
		@RequestMapping(value="/updatePwd", method={RequestMethod.GET,RequestMethod.POST})
		public ModelAndView updatePwd(@RequestParam("id") String id, @RequestParam("newPwd") String newPwd, HttpServletRequest request, HttpServletResponse response) throws Exception {
			ModelAndView mav = new ModelAndView();
			String viewName = "/main";
			UserVO user = new UserVO();
			user.setPwd(newPwd);
			user.setId(id);
			boolean flag = userService.updatePwd(user);
			if(flag) {
				viewName="/successUpdatePwd";
			}
			mav.setViewName(viewName);
			return mav;
		}
	
		//비번 보여주기(사용함)
		@RequestMapping(value = "/viewFindInfoPwd", method = RequestMethod.GET)
		public ModelAndView viewFindInfoPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
			ModelAndView mav = new ModelAndView();
			String viewName = "/viewFindInfoPwd";
			//System.out.println("viewFindInfoPwd");
			mav.setViewName(viewName);
			return mav;
		}
		
		/* 개인정보 수정 */
		@RequestMapping(value="/updateMyInfo", method= {RequestMethod.GET, RequestMethod.POST})
		public ModelAndView updateMyInfo(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) {
			ModelAndView mav = new ModelAndView();
			boolean flag = false;
			
			String id = request.getParameter("id");
			String name = request.getParameter("name");
			String pwd = request.getParameter("newPwd2");
			String pwdOld = request.getParameter("pwd");
			String email = request.getParameter("email");
			String phoneNum = request.getParameter("phoneNum");
			
			if(pwd == "") {
				user.setName(name);
				user.setEmail(email);
				user.setPhoneNum(phoneNum);
				user.setPwd(pwdOld);
				System.out.println(user);
			} else {
				user.setName(name);
				user.setPwd(pwd);
				user.setEmail(email);
				user.setPhoneNum(phoneNum);
				System.out.println("pwd2");
			}
			
			flag = userService.updateMyInfo(user); 
			
			if(flag) {
				mav.addObject("user", user);
				System.out.println("수정 완료");
			}
			
			System.out.println(user);
			mav.setViewName("redirect:/user/viewMyPage?id=" + id);
			return mav;
		}
		
		/* 비밀번호 체크 */
		@RequestMapping(value="/pwdCheck", method= {RequestMethod.GET, RequestMethod.POST})
		public ModelAndView pwdCheck(@RequestParam("id") String id,@RequestParam("pwd") String pwd, HttpServletRequest request, HttpServletResponse response) {
			ModelAndView mav = new ModelAndView();
			UserVO user = userService.selectUserPwd(id,pwd);
			String viewName = "/updateMyPage";
			
			boolean ckPwd = false;
			if (user != null) {
				request.getSession().setAttribute(pwd, user);
				ckPwd = true;
			} else {
				viewName = "/pwdCheckPage";
			}
			
			System.out.println(ckPwd);
			request.getSession().setAttribute("ckPwd", ckPwd);
			mav.setViewName(viewName);
			return mav;
		}
		
		/* 비밀번호 체크 페이지 */
		@RequestMapping(value="/pwdCheckPage", method= {RequestMethod.GET, RequestMethod.POST})
		public ModelAndView pwdCheckPage(HttpServletRequest request, HttpServletResponse response) {
			ModelAndView mav = new ModelAndView();
			mav.setViewName("/pwdCheckPage");
			return mav;
		}
		
		/* 마이페이지 보기 */
		@RequestMapping(value="/viewMyPage", method= {RequestMethod.GET, RequestMethod.POST})
		public ModelAndView viewMyPage(@RequestParam(required = false) String id, HttpServletRequest request, HttpServletResponse response) {
			ModelAndView mav = new ModelAndView();
			System.out.println("controller seq = " + id);
			UserVO user = userService.selectMyInfo(id);
		
			mav.addObject("member",user);
			mav.setViewName("/viewMyPage");
			return mav;
		}
	/*
	 * @RequestMapping(value="/list",method=RequestMethod.GET) public ModelAndView
	 * selectUser(HttpServletRequest request, HttpServletResponse response) throws
	 * Exception { ModelAndView mav = new ModelAndView();
	 * 
	 * String viewName = "/user/list"; ArrayList<UserVO> list =
	 * userService.selectUser(); mav.addObject("list",list);
	 * 
	 * mav.setViewName(viewName); return mav; }
	 * 
	 * @RequestMapping(value="/delete",method=RequestMethod.GET) public ModelAndView
	 * deleteUser(HttpServletRequest request, HttpServletResponse response) throws
	 * Exception { ModelAndView mav = new ModelAndView(); boolean flag = false; int
	 * seq = Integer.parseInt(request.getParameter("seq")); flag =
	 * userService.deleteUser(seq); String viewName = "error"; if(flag) { viewName =
	 * "redirect:/user/list"; } mav.setViewName(viewName);
	 * 
	 * return mav; }
	 */
}
