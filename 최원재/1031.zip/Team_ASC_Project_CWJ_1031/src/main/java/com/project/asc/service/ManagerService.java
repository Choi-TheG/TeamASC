package com.project.asc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.ManagerDAO;
import com.project.asc.vo.ProjectVO;
import com.project.asc.vo.UserVO;

@Service("managerService")
public class ManagerService {

	@Autowired
	private ManagerDAO managerDAO;
	
	/* 검색 */
	public ArrayList<UserVO> searchUserList(String word) {
		ArrayList<UserVO> list = new ArrayList<UserVO>();
		
		list = managerDAO.searchUserList(word);
		
		if(list == null) {
			System.out.println("list = null");
		}
		return list;
	}
	
	/* 상태(status) 'N'으로 바꾸기 */
	public boolean updateUserStatus(int seq) {
		boolean flag = false;
		
		flag = managerDAO.updateUserStatus(seq);
		
		return flag;
	}
	
	/* 회원정보 수정 */
	public boolean updateUserInfo(UserVO user) {
		boolean flag = false;
		
		flag = managerDAO.updateUserInfo(user);
		
//		System.out.println("updateService");
		return flag;
	}
	
	/* 회원 상세정보 페이지 가기 */
	public UserVO selectUserInfo(int seq) {
		UserVO user = null;
		user = managerDAO.selectUserInfo(seq);
		
		return user;
	}
	
	/* 전체 회원 목록 불러오기 */
	public ArrayList<UserVO> selectAll() {
		ArrayList<UserVO> list = null;
		
		list = managerDAO.selectAll();
		
		return list;
	}

	public ArrayList<ProjectVO> selectProjectAll(){
		ArrayList<ProjectVO> list = null;
		
		list = managerDAO.selectProjectAll();
		
		return list;
	}
}
