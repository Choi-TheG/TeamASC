package com.project.asc.service;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.TestDAO;

@Service("testService")
public class TestService {
	
	@Autowired
	private TestDAO testDAO;
	
	public boolean testService() {
		boolean flag = false;
		
		try {
			flag = testDAO.testDB();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return flag;
	}
}
