package asc.project.test.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/test")
public class MainController {
	
	@RequestMapping(value="main.do", method=RequestMethod.GET)
	public ModelAndView main(HttpServletResponse rep, HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		String viewName = "main";
		
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="login.do", method=RequestMethod.GET)
	public ModelAndView ViewLogin(HttpServletResponse rep, HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		String viewName = "viewLogin";
		
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="join.do", method=RequestMethod.GET)
	public ModelAndView ViewJoin(HttpServletResponse rep, HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		String viewName = "join";
		
		mav.setViewName(viewName);
		return mav;
	}
	
	
	
	//////////////////////////////////////////////////////////////////////////////
	private String getViewName(HttpServletRequest request) throws Exception {
		String contextPath = request.getContextPath();
		String uri = (String) request.getAttribute("javax.servlet.include.request_uri");
		if (uri == null || uri.trim().equals("")) {
			uri = request.getRequestURI();
		}

		
		int begin = 0; //
		if (!((contextPath == null) || ("".equals(contextPath)))) {
			begin = contextPath.length(); 
		}

		int end;
		if (uri.indexOf(";") != -1) {
			end = uri.indexOf(";");
		} else if (uri.indexOf("?") != -1) {
			end = uri.indexOf("?"); 
		} else {
			end = uri.length();
		}


		String fileName = uri.substring(begin, end);
		if (fileName.indexOf(".") != -1) {
			fileName = fileName.substring(0, fileName.lastIndexOf(".")); 
		}
		if (fileName.lastIndexOf("/") != -1) {
			fileName = fileName.substring(fileName.lastIndexOf("/"), fileName.length()); 
		}
		return fileName;
	}
}
