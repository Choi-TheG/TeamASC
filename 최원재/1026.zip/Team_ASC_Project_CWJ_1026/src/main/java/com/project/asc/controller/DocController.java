package com.project.asc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.DocService;
import com.project.asc.vo.DocVO;


@Controller("docController")
@RequestMapping("/doc")
public class DocController {
	@Autowired
	private DocService docService;
	
	//테스트
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public ModelAndView test(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("/doc/test");
		return mav;
	}
	
	// 문서 조회
	@RequestMapping(value="/readDoc",method={RequestMethod.POST, RequestMethod.GET})
	public ModelAndView readDoc(@RequestParam("docSeq") String docSeq, HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav = new ModelAndView();
		DocVO doc = docService.readDoc(docSeq);

		mav.addObject("doc",doc);
//		System.out.println("doc= "+doc);
		mav.setViewName("/doc/readDoc");
		return mav;
	}
	
	// 문서 수정 페이지
	@RequestMapping(value="/viewUpdate",method=RequestMethod.POST)
	public ModelAndView viewUpdate(@RequestParam("docSeq") String docSeq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		DocVO doc = docService.readDoc(docSeq);
		
		mav.addObject("doc",doc);
		mav.setViewName("/doc/viewUpdate");
		return mav;
	}

	// 문서 수정
	@RequestMapping(value="/updateDoc",method= {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView updateDoc(@ModelAttribute("doc") DocVO doc, @RequestParam("docSeq") String docSeq, HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav = new ModelAndView();
//		System.out.println(doc);
		boolean flag = docService.updateDoc(doc);
		if(flag) {
			System.out.println("update done.");
		}
		
		mav.setViewName("redirect:/doc/readDoc?docSeq="+docSeq);
		return mav;
	}

	// 문서 삭제
	@RequestMapping(value="/deleteDoc",method= {RequestMethod.POST, RequestMethod.GET})
	public ModelAndView deleteDoc(@ModelAttribute("doc") DocVO doc, @RequestParam("docSeq") String docSeq, HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav = new ModelAndView();
//		System.out.println(doc);
		boolean flag = docService.deleteDoc(doc);
		if(flag) {
			System.out.println("delete done.");
		}

		mav.setViewName("redirect:/doc/readDoc?docSeq="+docSeq);
		return mav;
	}
	
	// 예문
	@RequestMapping(value="examPlan",method=RequestMethod.GET)
	public ModelAndView examPlan(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		
		mav.setViewName("/doc/examPlan");
		return mav;
	}
}
