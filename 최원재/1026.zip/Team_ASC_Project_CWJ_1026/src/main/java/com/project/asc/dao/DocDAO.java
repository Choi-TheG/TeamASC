package com.project.asc.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.asc.vo.DocVO;

@Repository("docDAO")
public class DocDAO {

	@Autowired
	private SqlSession sqlSession;
	
	public DocVO selectDoc(String docSeq) {
		DocVO doc = null;
		doc = sqlSession.selectOne("mapper.doc.selectDocBySeq", Integer.parseInt(docSeq));
		
		return doc;
	}
	
	public boolean updateDoc(DocVO doc) {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.doc.updateDoc", doc);
		if(affectedCount > 0) {
			flag = true;
		}	
		return flag;
	}
	
	public boolean deleteDoc(DocVO doc) {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.doc.deleteDoc", doc);
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
}
