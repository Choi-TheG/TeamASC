package com.project.asc.vo;

public class DocumentsVO {
	private int documentsSeq;
	private int projectSeq;
	private int pageNum;
	private String documentsName;
	private String documentsItem1;
	private String documentsItem2;
	private String documentsItem3;
	private String documentsItem4;
	private String documentsItem5;
	private String documentsContent1;
	private String documentsContent2;
	private String documentsContent3;
	private String documentsContent4;
	private String documentsContent5;
	private String createDate;
	private String teamLeader;
	
	
	public DocumentsVO() {
		super();
	}

	public DocumentsVO(int documentsSeq, int projectSeq, int pageNum, String documentsName, String documentsItem1,
			String documentsItem2, String documentsItem3, String documentsItem4, String documentsItem5,
			String documentsContent1, String documentsContent2, String documentsContent3, String documentsContent4,
			String documentsContent5, String createDate, String teamLeader) {
		super();
		this.documentsSeq = documentsSeq;
		this.projectSeq = projectSeq;
		this.pageNum = pageNum;
		this.documentsName = documentsName;
		this.documentsItem1 = documentsItem1;
		this.documentsItem2 = documentsItem2;
		this.documentsItem3 = documentsItem3;
		this.documentsItem4 = documentsItem4;
		this.documentsItem5 = documentsItem5;
		this.documentsContent1 = documentsContent1;
		this.documentsContent2 = documentsContent2;
		this.documentsContent3 = documentsContent3;
		this.documentsContent4 = documentsContent4;
		this.documentsContent5 = documentsContent5;
		this.createDate = createDate;
		this.teamLeader = teamLeader;
	}
	
	public int getDocumentsSeq() {
		return documentsSeq;
	}
	public void setDocumentsSeq(int documentsSeq) {
		this.documentsSeq = documentsSeq;
	}
	public int getProjectSeq() {
		return projectSeq;
	}
	public void setProjectSeq(int projectSeq) {
		this.projectSeq = projectSeq;
	}
	
	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public String getDocumentsName() {
		return documentsName;
	}
	public void setDocumentsName(String documentsName) {
		this.documentsName = documentsName;
	}
	public String getDocumentsItem1() {
		return documentsItem1;
	}
	public void setDocumentsItem1(String documentsItem1) {
		this.documentsItem1 = documentsItem1;
	}
	public String getDocumentsItem2() {
		return documentsItem2;
	}
	public void setDocumentsItem2(String documentsItem2) {
		this.documentsItem2 = documentsItem2;
	}
	public String getDocumentsItem3() {
		return documentsItem3;
	}
	public void setDocumentsItem3(String documentsItem3) {
		this.documentsItem3 = documentsItem3;
	}
	public String getDocumentsItem4() {
		return documentsItem4;
	}
	public void setDocumentsItem4(String documentsItem4) {
		this.documentsItem4 = documentsItem4;
	}
	public String getDocumentsItem5() {
		return documentsItem5;
	}
	public void setDocumentsItem5(String documentsItem5) {
		this.documentsItem5 = documentsItem5;
	}
	public String getDocumentsContent1() {
		return documentsContent1;
	}
	public void setDocumentsContent1(String documentsContent1) {
		this.documentsContent1 = documentsContent1;
	}
	public String getDocumentsContent2() {
		return documentsContent2;
	}
	public void setDocumentsContent2(String documentsContent2) {
		this.documentsContent2 = documentsContent2;
	}
	public String getDocumentsContent3() {
		return documentsContent3;
	}
	public void setDocumentsContent3(String documentsContent3) {
		this.documentsContent3 = documentsContent3;
	}
	public String getDocumentsContent4() {
		return documentsContent4;
	}
	public void setDocumentsContent4(String documentsContent4) {
		this.documentsContent4 = documentsContent4;
	}
	
	public String getDocumentsContent5() {
		return documentsContent5;
	}

	public void setDocumentsContent5(String documentsContent5) {
		this.documentsContent5 = documentsContent5;
	}

	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	
	public String getTeamLeader() {
		return teamLeader;
	}

	public void setTeamLeader(String teamLeader) {
		this.teamLeader = teamLeader;
	}

	@Override
	public String toString() {
		return "DocumentsVO [documentsSeq=" + documentsSeq + ", projectSeq=" + projectSeq + ", pageNum=" + pageNum
				+ ", documentsName=" + documentsName + ", documentsItem1=" + documentsItem1 + ", documentsItem2="
				+ documentsItem2 + ", documentsItem3=" + documentsItem3 + ", documentsItem4=" + documentsItem4
				+ ", documentsItem5=" + documentsItem5 + ", documentsContent1=" + documentsContent1
				+ ", documentsContent2=" + documentsContent2 + ", documentsContent3=" + documentsContent3
				+ ", documentsContent4=" + documentsContent4 + ", documentsContent5=" + documentsContent5
				+ ", createDate=" + createDate + ", teamLeader=" + teamLeader + "]";
	}
}
