create table documents(
	doc_seq int primary key auto_increment,
    project_seq int not null,
    doc_name varchar(50) not null default('프로젝트 기획안'),
    doc_item1 text not null default('이름'),
    doc_item2 text not null default('타이틀'),
    doc_item3 text not null default('주제'),
    doc_item4 text not null default('내용'),
    doc_item5 text not null default('구체화방향'),
    doc_content1 text not null default('프로젝트 이름'),
    doc_content2 text not null default('프로젝트 제목'),
    doc_content3 text not null default('프로젝트 주제'),
    doc_content4 text not null default('프로젝트 내용'),
    doc_content5 text not null default('프로젝트 내용을 구현하기 위한 기능'),
    create_date varchar(8) not null default('20021001'),
    insert_time datetime,
    update_time datetime
);

insert into documents(doc_seq, project_seq)
values(1,1,'프로젝트 기획안', '이름', '타이틀', '주제', '내용', '구체화방향',
'프로젝트  이름', '프로젝트 제목', '프로젝트 주제', '프로젝트 내용', '프로젝트 내용을 구현하기 위한 기능', '20021001');