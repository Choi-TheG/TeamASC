package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.DashService;
import com.project.asc.vo.DocVO;

@Controller("dashController")
@RequestMapping("/dash")
public class DashController {

	@Autowired
	private DashService dashService;
	
	
	@RequestMapping(value="/productList", method=RequestMethod.GET)
	public ModelAndView productList(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		ArrayList<DocVO> list = dashService.productList();
		
		mav.addObject("list", list);
		mav.setViewName("/dash/productList");
		return mav;
	}
}
