package com.project.asc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.DashDAO;
import com.project.asc.vo.DocVO;

@Service("dashService")
public class DashService {

	@Autowired
	private DashDAO dashDAO;
	
	public ArrayList<DocVO> productList() {
		ArrayList<DocVO> dash = null;
		dash = dashDAO.selectAllDoc();
		
		return dash;
	}

}
