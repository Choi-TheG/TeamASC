package com.project.asc.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.asc.vo.DocVO;

@Repository("dashDAO")
public class DashDAO {
	@Autowired
	private SqlSession sqlSession;
	
	public ArrayList<DocVO> selectAllDoc() {
		ArrayList<DocVO> dash = null;
		dash = (ArrayList)sqlSession.selectList("mapper.doc.selectDashList");
		for(DocVO vo : dash) {
			System.out.println(vo);
		}
		return dash;
	}

}
