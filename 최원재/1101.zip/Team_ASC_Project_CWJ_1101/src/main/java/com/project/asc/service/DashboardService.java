package com.project.asc.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.DashboardDAO;
import com.project.asc.vo.BoardVO;
import com.project.asc.vo.DocumentsVO;

@Service("dashboardService")
public class DashboardService {

	@Autowired
	private DashboardDAO dashboardDAO;

	public ArrayList<BoardVO> selectErrorBoard(String projectSeq) {
		// TODO Auto-generated method stub
		System.out.println("1");
		ArrayList<BoardVO> list = null;
		try {
			list = dashboardDAO.selectErrorBoard(projectSeq);
			System.out.println("2");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<DocumentsVO> productList(String projectSeq) {
		ArrayList<DocumentsVO> dashboard = null;
		dashboard = dashboardDAO.selectAllDocuments(projectSeq);
		
		return dashboard;
	}
}
