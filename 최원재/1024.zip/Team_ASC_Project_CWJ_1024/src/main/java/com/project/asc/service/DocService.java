package com.project.asc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.DocDAO;
import com.project.asc.vo.DocVO;

@Service("docService")
public class DocService {
	@Autowired
	private DocDAO docDAO;
	
	public DocVO readDoc(String docSeq) {
		DocVO doc = null;
		doc = docDAO.selectDoc(docSeq);
		
		return doc;
	}
	
	public boolean updateDoc(DocVO doc) {
		boolean flag = false;
		docDAO.updateDoc(doc);
		
		return flag;
	}
}
