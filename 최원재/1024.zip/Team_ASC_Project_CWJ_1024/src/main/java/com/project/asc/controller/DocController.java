package com.project.asc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.DocService;
import com.project.asc.vo.DocVO;


@Controller("docController")
@RequestMapping("/doc")
public class DocController {
	@Autowired
	private DocService docService;
	
	// 문서 조회
	@RequestMapping(value="/readDoc",method={RequestMethod.POST, RequestMethod.GET})
	public ModelAndView readDoc(@RequestParam("docSeq") String docSeq, HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav = new ModelAndView();
		DocVO doc = docService.readDoc(docSeq);

		mav.addObject("doc",doc);
		mav.setViewName("/doc/readDoc");
		return mav;
	}
	
	// 문서 수정 페이지
	@RequestMapping(value="/viewUpdate",method=RequestMethod.POST)
	public ModelAndView viewUpdate(@RequestParam("docSeq") String docSeq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		DocVO doc = docService.readDoc(docSeq);
		
		mav.addObject("doc",doc);
		mav.setViewName("/doc/viewUpdate");
		return mav;
	}

	// 문서 수정
	@RequestMapping(value="/updateDoc",method=RequestMethod.POST)
	public ModelAndView docUpdate(@ModelAttribute("info") DocVO doc, HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("redirect:/doc/readDoc");
		return mav;
	}

	// 문서 삭제
	@RequestMapping(value="/deleteDoc",method=RequestMethod.POST)
	public ModelAndView docDelete(HttpServletRequest request, HttpServletResponse response) throws Exception  {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("/doc/deleteDoc.do");
		return mav;
	}
	
	// 예문
	@RequestMapping(value="examPlan",method=RequestMethod.POST)
	public ModelAndView examPlan(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("/doc/examPlan.do");
		return mav;
	}
}
