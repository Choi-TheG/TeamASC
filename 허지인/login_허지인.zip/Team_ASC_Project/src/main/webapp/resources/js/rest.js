/**
 * 
 */
 $(document).ready(function(){
		$('#btn1').on('click', function(){
			$.ajax({
				type:'get',
				url:'all',
				dataType:'text',
				success:function(data,status){
					
					let arrayObj = JSON.parse(data);
					for (let i=0;i<arrayObj.length;i++){
						let jsonObj = arrayObj[i];
						alert(jsonObj.replySeq+","+jsonObj.replyContent);
						//이어서
						
					}
				},
				error:function(data,status){
					alert('error '+status);
				},
				complete:function(xhr,status){
					
				}
			});
		});//btn1
		
		$('#btn2').on('click', function(){
			$.ajax({
				type:'get',
				url:'15',
				dataType:'text',
				success:function(data,status){
					alert(data);
					let jsonObj = JSON.parse(data);
				},
				error:function(data,status){
					alert('error '+status);
				},
				complete:function(xhr,status){
					
				}
			});
		});//btn2
		
		$('#btn3').on('click', function(){
			let reply = {
					replySeq : 20,
					replyContent : "from javascript content",
					gbSeq : 5
			};
			$.ajax({
				type:'put',
				url:'12',
				dataType:'text',
				contentType:'application/json',
				data:JSON.stringify(reply),
				success:function(data,status){
					alert(data);
				},
				error:function(data,status){
					alert('error '+status);
				},
				complete:function(xhr,status){
					
				}
			});
		});//btn3
		
		$('#btn4').on('click', function(){
			$.ajax({
				type:'delete',
				url:'12',
				dataType:'text',
				success:function(data,status){
					alert(data);
				},
				error:function(data,status){
					alert('error '+status);
				},
				complete:function(xhr,status){
					
				}
			});
		});//btn4
		
		$('#btn5').on('click', function(){
			let reply = {
					replySeq : 20,
					replyContent : "from javascript content",
					gbSeq : 5
			};
			$.ajax({
				type:'post',
				url:'./',
				dataType:'text',
				contentType:'application/json',
				data:JSON.stringify(reply),
				success:function(data,status){
					alert(data);
				},
				error:function(data,status){
					alert('error '+status);
				},
				complete:function(xhr,status){
					console.log(xhr.status);
				}
			});
		});//btn5
		
	});