package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.UserService;
import com.project.asc.vo.UserVO;

@RequestMapping("/user")
@Controller("userController")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/main",method=RequestMethod.GET)
	public ModelAndView main(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/main";
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView selectUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "user";
		ArrayList<UserVO> list = userService.selectUser();
		mav.addObject("list",list);
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/viewJoin",method=RequestMethod.GET)
	public ModelAndView createUserPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "createUser";
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/joinUser",method=RequestMethod.POST)
	public ModelAndView createUser(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		flag = userService.insertUser(user);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/user/list";
		} 
		mav.setViewName(viewName);
		return mav;
	}
	
	
	@RequestMapping(value = "/viewLogin", method = RequestMethod.GET)
	public ModelAndView viewLogin(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewLogin";
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam("id") String id, @RequestParam("pwd") String pwd, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/loginMain";

		UserVO user = userService.selectUser(id,pwd);
		System.out.println(user);
		boolean isLogon = false;
		if (user != null) {
			request.getSession().setAttribute("member", user);
			isLogon = true;
		} else {
			viewName = "/viewLogin";
		}
		System.out.println(isLogon);
		
		request.getSession().setAttribute("isLogon", isLogon);
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/logout", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/main";
		request.getSession().invalidate();
		mav.setViewName(viewName);
		return mav;
	}
	
	public ModelAndView newProject(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String teamCategory = request.getParameter("teamCategory");
		
		return mav;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView deleteUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		int seq = Integer.parseInt(request.getParameter("seq"));
		flag = userService.deleteUser(seq);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/user/list";
		} 
		mav.setViewName(viewName);
		return mav;
	}
}
