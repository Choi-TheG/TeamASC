package com.project.asc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.UserDAO;
import com.project.asc.vo.UserVO;

@Service("userService")
public class UserService {
	
	@Autowired
	private UserDAO userDAO;
	
	public ArrayList<UserVO> selectUser() {
		ArrayList<UserVO> list = null;
		list = userDAO.selectUser();
		return list;
	}
	
	public boolean insertUser(UserVO user) {
		boolean flag = false;
		flag = userDAO.InsertUser(user);
		return flag;
	}
	
	public boolean deleteUser(int seq) {
		boolean flag = false;
		flag = userDAO.deleteUser(seq);
		return flag;
	}
	
	public UserVO selectUser(String id, String pwd) {
		UserVO user = new UserVO();
		user.setId(id);
		user.setPwd(pwd);
		UserVO vo = null;
		vo = userDAO.selectUser(user);
		return vo;
	}
}
