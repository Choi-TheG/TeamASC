package com.project.asc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.UserDAO;
import com.project.asc.vo.UserVO;

@Service("restService")
public class RestService {
	
	@Autowired
	private UserDAO userDAO;

	public boolean checkUser(String id) {
		// TODO Auto-generated method stub
		boolean flag = userDAO.checkUser(id);
		
		return flag;
	}

}
