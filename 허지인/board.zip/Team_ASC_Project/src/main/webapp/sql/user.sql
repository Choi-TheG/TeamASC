create database tasc;
show tables;
use tasc;

create table user(
user_seq integer auto_increment primary key,
id varchar(50) not null default(''),
pwd varchar(50) not null default(''),
name varchar(50) not null default(''),
email varchar(100) not null default(''),
phone_num varchar(20) not null default(''),
join_date varchar(8) not null default(DATE_FORMAT(now(), '%Y%m%d')),
status varchar(20) not null default(''),

insert_time datetime default(now()),
update_time datetime
); 
desc user;
select * from user;
insert into user(id,pwd,name,email,phone_num,status) 
value ('admin','1234','관리자','admin@email.com','010-0000-0000','Y');

create table team_member(
team_member_seq integer auto_increment primary key,
user_seq integer not null default(0),
team_id varchar(50) not null default(''),
team_leader varchar(1) not null default(''),
create_date varchar(8) not null default(DATE_FORMAT(now(), '%Y%m%d')),
team_category varchar(1) not null default(''),

insert_time datetime default(now()),
update_time datetime
);

select * from team_member;

create table message(
message_seq integer auto_increment primary key,
from_user_seq integer not null default(''),
to_user_seq integer not null default(''),
content text not null default(''),
invite_yn varchar(1) not null default(''),
confirm_yn varchar(1) not null default('N'),
send_date varchar(8) not null default(now()),

insert_time datetime default(now()),
update_time datetime
);

create table document(
doc_seq integer auto_increment primary key,
project_seq integer not null default(0),
doc_name varchar(50) not null default(''),
doc_item varchar(10) not null default(''),
doc_content text not null default(''),
create_date varchar(8) not null default(DATE_FORMAT(now(), '%Y%m%d')),

insert_time datetime default(now()),
update_time datetime
);

create table project(
project_seq integer auto_increment primary key,
team_id varchar(50) not null default(''),
project_name varchar(100) not null default(''),
finish_yn varchar(1) not null default('N'),
percentage integer not null default(0),
create_date varchar(8) not null default(DATE_FORMAT(now(), '%Y%m%d')),

insert_time datetime default(now()),
update_time datetime
);

select * from project;

create table calendar(
calendar_seq integer auto_increment primary key,
project_seq integer not null default(0),
calendar_category varchar(20) not null default(''),
start_date varchar(8) not null default(''),
end_date varchar(8) not null default(''),
content varchar(50) not null default(''),
finish_yn varchar(1) not null default('N'),

insert_time datetime default(now()),
update_time datetime
);

create table board (
board_seq integer auto_increment primary key,
user_seq integer not null default(0),
project_seq integer not null default(0),
board_category varchar(10) not null default (''),
board_title varchar(100) not null default(''),
board_content text not null default(''),
complete_yn varchar(1) not null default('N'),
create_date varchar(8) not null default(DATE_FORMAT(now(), '%Y%m%d')),

insert_time datetime default(now()),
update_time datetime
);

select * from user;
select * from board;
select * from team_member;
select * from project;

   select b.board_seq,b.user_seq,b.project_seq,b.board_category,b.board_title,b.board_content,b.complete_yn,b.create_date, u.id 
        from board b
		left join user u
		on b.user_seq=u.user_seq
		where b.project_seq='1' and b.complete_yn = 'N';