package com.project.asc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.BoardService;
import com.project.asc.service.ProjectService;
import com.project.asc.service.UserService;
import com.project.asc.vo.BoardVO;
import com.project.asc.vo.ProjectVO;

@Controller("boardController")
@RequestMapping("/board")
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	private UserService userService;
	
	//게시판 리스트 조회(프로젝트 번호로)
	@RequestMapping(value="/boardList", method=RequestMethod.GET)
	public ModelAndView boardList(@RequestParam("projectSeq") String projectSeq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		//유저seq로 유저id 찾아줘야함!!!!!
		String viewName = "/boardList";
		ArrayList<BoardVO> list = boardService.selectAllBoard(projectSeq);
		mav.addObject("list", list);
		mav.setViewName(viewName);
		return mav;
	}
	
	//게시판 작성 페이지
	@RequestMapping(value="/viewWriteBoard", method=RequestMethod.GET)
	public ModelAndView viewWriteBoard(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewWriteBoard";
		mav.setViewName(viewName);
		return mav;
	}
	
	//게시글 등록(등록 후 게시판 리스트 조회 화면으로)
	@RequestMapping(value="/writeBoard", method= RequestMethod.POST)
	public ModelAndView writeBoard(@ModelAttribute("info") BoardVO board, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();

		System.out.println("writeBoard = "+board);
		boolean flag = boardService.insertBoard(board);
		if(flag) {
			System.out.println("게시글 등록");
			mav.addObject("board", board);
		}
		System.out.println("controller");
		String viewName = "redirect:./boardList?projectSeq="+board.getProjectSeq();

		mav.setViewName(viewName);
		return mav;
	}
	
	//상세조회 페이지(게시글 읽기) 이동
	@RequestMapping(value="/readBoard", method=RequestMethod.GET)
	public ModelAndView readBoard(@RequestParam("boardSeq") String boardSeq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/readBoard";
		
		BoardVO board = boardService.selectOneBoard(boardSeq);
	
		mav.addObject("board", board);
		mav.setViewName(viewName);
		return mav;
	}
	
	//수정페이지 이동
	@RequestMapping(value="/viewUpdateBoard", method=RequestMethod.GET)
	public ModelAndView viewUpdateBoard(@RequestParam("boardSeq") String boardSeq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewUpdateBoard";
		BoardVO board = boardService.selectOneBoard(boardSeq);
		mav.addObject("board", board);
		mav.setViewName(viewName);
		return mav;
	}
	
	//게시글 수정(수정 후 게시글 상세조회 화면으로)
	@RequestMapping(value="/updateBoard", method = RequestMethod.POST)
	public ModelAndView updateBoard(@ModelAttribute("info") BoardVO board, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewUpdateBoard";
		String boardTitle = request.getParameter("boardTitle");
		String boardContent = request.getParameter("boardContent");
		String completeYn = request.getParameter("completeYn");
		String boardSeq = request.getParameter("boardSeq");
		board.setBoardTitle(boardTitle);
		board.setBoardContent(boardContent);
		board.setCompleteYn(completeYn);
		System.out.println("update = "+board);
		boolean flag = boardService.updateBoard(board);
		if(flag) {
			mav.addObject("board", board);
			viewName = "redirect:./readBoard?boardSeq="+boardSeq;
		}
		mav.setViewName(viewName);
		return mav;
	}
	
	//게시글 삭제(삭제 후 게시판 조회 화면)
	@RequestMapping(value="/deleteBoard", method = {RequestMethod.POST,RequestMethod.GET})
	public ModelAndView deleteBoard(@RequestParam("boardSeq") String boardSeq, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String projectSeq=request.getParameter("projectSeq");
		String viewName = "redirect:../main";
		boolean flag = boardService.deleteBoard(boardSeq);
		if(flag) {
			viewName = "redirect:./boardList?projectSeq="+projectSeq;
		}
		mav.setViewName(viewName);
		return mav;
	}
		
	//게시판 리스트 조회 페이징(프로젝트 번호로)
	@RequestMapping(value="/boardListPaging", method=RequestMethod.GET)
	public ModelAndView boardListPaging(Model model, @RequestParam(defaultValue="1") int curPage, @RequestParam("projectSeq") String projectSeq, @ModelAttribute("info") BoardVO board, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
	
		return mav;
	}
	
	
}
