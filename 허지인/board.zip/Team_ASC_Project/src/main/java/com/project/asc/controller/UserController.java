package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.UserService;
import com.project.asc.vo.UserVO;

@RequestMapping("/user")
@Controller("userController")
public class UserController {
	
	@Autowired
	private UserService userService;

	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView selectUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "user";
		ArrayList<UserVO> list = userService.selectUser();
		mav.addObject("list",list);
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/viewJoinPage",method=RequestMethod.GET)
	public ModelAndView createUserPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		String viewName = "/user/viewJoinPage";
		
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/createUser",method=RequestMethod.POST)
	public ModelAndView createUser(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		
		flag = userService.inserUser(user);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/main";
		} 
		mav.setViewName(viewName);
		
		return mav;
	}
	
	//로그인 페이지
	@RequestMapping(value = "/viewLogin", method = RequestMethod.GET)
	public ModelAndView viewLogin(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewLogin";
		mav.setViewName(viewName);
		return mav;
	}
	
	
	//로그인
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam("id") String id, @RequestParam("pwd") String pwd, @RequestParam("projectYN") String projectYN, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		System.out.println("login");
		String viewName = "redirect:/main";

		UserVO user = userService.selectUser(id,pwd);
		boolean isLogon = false;
		if (user != null) {
			request.getSession().setAttribute("member", user);
			isLogon = true;
			System.out.println("projectYN "+projectYN);
			viewName = "redirect:/main";
			if(projectYN.equals("Y")) {
				viewName = "redirect:/project/createProjectPage";
				System.out.println("projectYN = "+projectYN);
			}
		} else {
			viewName = "/viewLogin";
		}
		System.out.println(isLogon);
		System.out.println("viewName = "+viewName);
		request.getSession().setAttribute("isLogon", isLogon);
		mav.setViewName(viewName);
		return mav;
	}
	
	//로그아웃
	@RequestMapping(value="/logout", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/main";
		request.getSession().invalidate();
		mav.setViewName(viewName);
		return mav;
	}
	
	//아이디 찾기 페이지
	@RequestMapping(value = "/viewFindInfo", method = RequestMethod.GET)
	public ModelAndView viewFindInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewFindInfo";
		//System.out.println("findInfo");
		mav.setViewName(viewName);
		return mav;
	}
	
	//아이디 찾기
	@RequestMapping(value = "/findInfoId", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView findInfoId(@RequestParam("name") String name, @RequestParam("email") String email, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/error";
		UserVO user = new UserVO();
		user.setName(name);
		user.setEmail(email);
		
		String id = userService.findId(user);
		
		if (id != null) {
			request.getSession().setAttribute("id", id);
			viewName = "/viewId";
		} 
		request.getSession().setAttribute("id", id);
		mav.setViewName(viewName);
		return mav;
	}
	
	//비번찾기 페이지
	@RequestMapping(value = "/findInfoPwd", method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView findInfoPwd(@RequestParam("id") String id, @RequestParam("name") String name, @RequestParam("email") String email, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/error";
		UserVO user = new UserVO();
		user.setId(id);
		user.setName(name);
		user.setEmail(email);
		
		String pwd = userService.findPwd(user);
		
		if (pwd != null) {
			request.getSession().setAttribute("user", user);
			viewName = "/updatePwd";
		} 
		mav.setViewName(viewName);
		return mav;
	}

	//비번 보여주기(사용안함)
	@RequestMapping(value = "/viewFindInfoPwd", method = RequestMethod.GET)
	public ModelAndView viewFindInfoPwd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/viewFindInfoPwd";
		//System.out.println("viewFindInfoPwd");
		mav.setViewName(viewName);
		return mav;
	}
	
	//비밀번호 새로 설정
	@RequestMapping(value="/updatePwd", method={RequestMethod.GET,RequestMethod.POST})
	public ModelAndView updatePwd(@RequestParam("id") String id, @RequestParam("newPwd") String newPwd, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "/main";
		UserVO user = new UserVO();
		user.setPwd(newPwd);
		user.setId(id);
		boolean flag = userService.updatePwd(user);
		if(flag) {
			viewName="/successUpdatePwd";
		}
		mav.setViewName(viewName);
		return mav;
	}
	

	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView deleteUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		int seq = Integer.parseInt(request.getParameter("seq"));
		flag = userService.deleteUser(seq);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/user/list";
		} 
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value = "/viewLogionBeforeProject", method = RequestMethod.GET)
	public ModelAndView viewLogionBeforeProject(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "redirect:./viewLogin";
		System.out.println("viewLogionBeforeProject");
		mav.addObject("project","Y");
		mav.setViewName(viewName);
		return mav;
	}
	
	//rest 로그인 체크
	@RequestMapping(value="/checkIdPwd",method=RequestMethod.GET)
	public boolean checkUserIdPwd(@RequestParam("userId") String userId,@RequestParam("userPwd") String userPwd, HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean flag = false;
		flag = userService.checkId(userId,userPwd);
		return flag;
	}
		
	//rest 아이디 중복 체크
	@RequestMapping(value="/checkId",method=RequestMethod.GET)
	public boolean checkUserId(@RequestParam("userId") String userId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean flag = false;
		flag = userService.checkId(userId);
		return flag;
	}
		

			
}
