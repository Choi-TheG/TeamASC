package com.project.asc.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.RestService;
import com.project.asc.vo.UserVO;


@RestController("restMainController")
@RequestMapping("/rest")
public class RestMainController {
	
	@Autowired
	private RestService restService;
	
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public String test() {
		return "test";
	}
	
	@RequestMapping(value="/viewSimpleReq", method=RequestMethod.GET)
	public ModelAndView viewSimpleReq() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("simpleReq");
		return mav;
	}
	
		@RequestMapping(value="/user/check", method=RequestMethod.GET)
		public ResponseEntity<String> checkId(@PathVariable("id") String id) {

			boolean flag = false;
			flag = restService.checkUser(id);
//			if(flag) {
//				System.out.println("사용가능한 아이디입니다.");
//			} else {
//				System.out.println("중복입니다.");
//			}
			return new ResponseEntity<String>(String.valueOf(flag),HttpStatus.OK);
		}
	
	
}
