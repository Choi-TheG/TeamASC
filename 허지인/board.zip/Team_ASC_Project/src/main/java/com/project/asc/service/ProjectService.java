package com.project.asc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.ProjectDAO;
import com.project.asc.vo.ProjectVO;
import com.project.asc.vo.TeamMemberVO;
import com.project.asc.vo.UserVO;

@Service("projectService")
public class ProjectService {
	
	@Autowired
	private ProjectDAO projectDAO;
	
	public boolean checkProjectName(String projectName) {
		boolean flag = false;
		
		flag = projectDAO.checkProjectName(projectName);
		
		return flag;
	}
	
	public boolean createProject(String projectName,UserVO userVo) {
		boolean flag = false;
		
		flag = projectDAO.createProject(projectName,userVo);
		
		return flag;
	}
	
	public ArrayList<ProjectVO> selectProjectList(int userSeq){
		ArrayList<ProjectVO> list = null;
		
		list = projectDAO.selectProjectList(userSeq);
		
		return list;
	}
	
	public ProjectVO setProject(String seq) {
		ProjectVO vo = null;
		
		vo = projectDAO.setProject(seq);
		
		return vo;
	}
	
	public ArrayList<TeamMemberVO> selectTeamMemberList(String teamId){
		ArrayList<TeamMemberVO> list = null;
		
		list = projectDAO.selectTeamMemberList(teamId);
		
		return list;
	}
	
	public boolean deleteTeamMember(String userSeq,String teamId) {
		boolean flag = false;
		
		flag = projectDAO.deleteTeamMember(userSeq,teamId);
		
		return flag;
	}
}
