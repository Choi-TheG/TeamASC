package com.project.asc.vo;

public class BoardVO {
	private int boardSeq;
	private int userSeq;
	private int projectSeq;
	private String boardCategory;
	private String boardTitle;
	private String boardContent;
	private String completeYn;
	private String createDate;
	private String id;

	public BoardVO() {};
	public BoardVO(int boardSeq, int userSeq, int projectSeq, String boardCategory, 
			String boardTitle, String boardContent, String completeYn, String createDate, String id) {
		this.boardSeq = boardSeq;
		this.userSeq = userSeq;
		this.projectSeq = projectSeq;
		this.boardCategory = boardCategory;
		this.boardTitle = boardTitle;
		this.boardContent = boardContent;
		this.completeYn = completeYn;
		this.createDate = createDate;
		this.id = id;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getBoardSeq() {
		return boardSeq;
	}
	public void setBoardSeq(int boardSeq) {
		this.boardSeq = boardSeq;
	}
	public int getUserSeq() {
		return userSeq;
	}
	public void setUserSeq(int userSeq) {
		this.userSeq = userSeq;
	}
	public int getProjectSeq() {
		return projectSeq;
	}
	public void setProjectSeq(int projectSeq) {
		this.projectSeq = projectSeq;
	}
	public String getBoardCategory() {
		return boardCategory;
	}
	public void setBoardCategory(String boardCategory) {
		this.boardCategory = boardCategory;
	}
	public String getBoardTitle() {
		return boardTitle;
	}
	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}
	public String getBoardContent() {
		return boardContent;
	}
	public void setBoardContent(String boardContent) {
		this.boardContent = boardContent;
	}
	public String getCompleteYn() {
		return completeYn;
	}
	public void setCompleteYn(String completeYn) {
		this.completeYn = completeYn;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	};
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return boardSeq+","+userSeq+","+projectSeq+","+boardCategory+","+boardTitle+","+boardContent+","+completeYn+","+createDate;
	}

}
