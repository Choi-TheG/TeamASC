package com.project.asc.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.asc.vo.BoardVO;

@Repository("boardDAO")
public class BoardDAO {

	@Autowired
	private SqlSession sqlSession;

	public boolean insertBoard(BoardVO board) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		System.out.println("dao");
		int affectedCount = sqlSession.insert("mapper.board.insertBoard", board);
		if (affectedCount>0) {
			System.out.println(board);
			flag = true;
		}
		return flag;
	}

	public ArrayList<BoardVO> selectAllBoard(String projectSeq) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("3");
		ArrayList<BoardVO> list = (ArrayList)sqlSession.selectList("mapper.board.selectBoardByProjectSeq", projectSeq);
		return list;
	}

	public BoardVO selectOneBoard(String boardSeq) throws SQLException {
		// TODO Auto-generated method stub
		BoardVO board = sqlSession.selectOne("mapper.board.selectBoardByboardSeq", boardSeq);
		return board;
	}

	public boolean updateBoard(BoardVO board) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.updateBoard", board);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	public boolean deleteBoard(String boardSeq) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.delete("mapper.board.deleteBoard",boardSeq);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	public List<Object> searchId() throws SQLException {
		// TODO Auto-generated method stub
		List<Object> writerList = sqlSession.selectList("mapper.board.selectIdByUserSeq");
		return writerList;
	}

	public int selectAllCnt(String projectSeq) throws SQLException {
		// TODO Auto-generated method stub
		int listCnt = sqlSession.selectOne("mapper.board.boardCnt", projectSeq);
		return listCnt;
	}

	
	
}
