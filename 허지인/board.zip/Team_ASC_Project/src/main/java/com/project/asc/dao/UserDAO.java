package com.project.asc.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.project.asc.vo.UserVO;

@Repository("userDAO")
public class UserDAO {
	
	@Autowired
	private SqlSession sqlSession; 
	
	public ArrayList<UserVO> selectUser() {
		ArrayList<UserVO> list = null;
		
		list = (ArrayList) sqlSession.selectList("mapper.user.selectUser");
		
		return list;
	}
	
	public boolean InsertUser(UserVO user) {
		boolean flag = false;
		
		int affectedCount = sqlSession.insert("mapper.user.insertUser", user);
		
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	public boolean deleteUser(int seq) {
		boolean flag = false;
		
		int affectedCount = sqlSession.delete("mapper.user.deleteUser", seq);
		
		if(affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}

	public boolean checkUser(String id) {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.selectOne("mapper.user.checkUser", id);
		if(affectedCount != 1) {
			flag = true;
		}
		return flag;
	}

	public UserVO selectUser(UserVO user) {
		// TODO Auto-generated method stub
		UserVO vo = new UserVO();
		vo = sqlSession.selectOne("mapper.user.checkUserByIdPwd",user);
		//System.out.println("DAO vo = "+vo);
		return vo;
	}

	public String findId(UserVO user) {
		// TODO Auto-generated method stub
		String id = sqlSession.selectOne("mapper.user.findId", user);
		//System.out.println(id);
		return id;
	}

	public String findPwd(UserVO user) {
		// TODO Auto-generated method stub
		String pwd = sqlSession.selectOne("mapper.user.findPwd", user);
		return pwd;
	}

	public String selectUserId(String userSeq) {
		// TODO Auto-generated method stub
		String userId = sqlSession.selectOne("mapper.user.selectUserIdBySeq", userSeq);
		return userId;
	}
	
	public boolean checkId(String userId) {
		boolean flag = false;
		
		int affectedCount = sqlSession.selectOne("mapper.user.checkId",userId);
		
		if(affectedCount != 1) {
			flag = true;
		}
		
		return flag;
	}
	
	public boolean checkId(String userId,String userPwd) {
		boolean flag = false;
		UserVO vo = new UserVO();
		vo.setId(userId);
		vo.setPwd(userPwd);
		
		int affectedCount = sqlSession.selectOne("mapper.user.checkUserByIdPwd2",vo);
		
		if(affectedCount == 1) {
			flag = true;
		}
		return flag;
	}

	public boolean updatePwd(UserVO user) {
		// TODO Auto-generated method stub
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.user.updatePwd", user);
		if(affectedCount > 0) {
			flag = true;
		}
		return flag;
	}
	
	
}
