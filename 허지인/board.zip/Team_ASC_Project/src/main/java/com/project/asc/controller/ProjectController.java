package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.ProjectService;
import com.project.asc.vo.ProjectVO;
import com.project.asc.vo.TeamMemberVO;
import com.project.asc.vo.UserVO;
@ResponseBody
@RequestMapping("/project")
@Controller("projectController")
public class ProjectController {

	@Autowired
	private ProjectService projectService;
	
	@RequestMapping(value="/deleteTeamMember",method=RequestMethod.GET)
	public ModelAndView deleteTeamMember(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		
		String viewName = "redirect:/loginMain";
		
		String userSeq = request.getParameter("userSeq");
		String teamId = request.getParameter("teamId");
		
		boolean flag = projectService.deleteTeamMember(userSeq,teamId);
		
		if(flag) {
			viewName = "redirect:/project/manageProjectPage";
		}
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/readProject",method=RequestMethod.GET)
	public ModelAndView readProject(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		
		String viewName = "redirect:/project/viewProjectPage";
		
		String projectSeq = request.getParameter("seq");
		
		ProjectVO project = projectService.setProject(projectSeq);
		
		request.getSession().setAttribute("project", project);
		
		//시작일자 YYYY-mm-DD로 형식 변경
		String creatDate = project.getCreateDate();
		project.setCreateDate(creatDate.substring(0,4) + "-" + creatDate.substring(4,6) + "-" + creatDate.substring(6,8));
		
		//완료여부 문구 변경
		String finishYn = project.getFinishYn();
		if(finishYn=="Y") {
			project.setFinishYn("완료");
		} else {
			project.setFinishYn("진행중");
		}
		
		mav.setViewName(viewName);
		
		return mav;
	}
	@RequestMapping(value="/returnLoginMain",method=RequestMethod.GET)
	public ModelAndView returnLoginMain(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		
		request.getSession().setAttribute("project", null);
		
		String viewName = "redirect:/main";
		
		mav.setViewName(viewName);
		
		return mav;
	}
	@RequestMapping(value="/viewProjectPage",method=RequestMethod.GET)
	public ModelAndView viewProjectPage(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		
		String viewName = "/project/viewProjectPage";
		
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/manageProjectPage",method=RequestMethod.GET)
	public ModelAndView projectManage(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		
		ProjectVO vo = (ProjectVO) request.getSession().getAttribute("project");
		
		String teamId = vo.getTeamId();
		
		ArrayList<TeamMemberVO> list = projectService.selectTeamMemberList(teamId);
		
		String viewName = "/project/manageProjectPage";
		
		mav.addObject("list",list);
		
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/createProjectPage",method=RequestMethod.GET)
	public ModelAndView createProjectPagae(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		String viewName ="/project/createProjectPage";
		
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/createProject",method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView createProject(HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		String projectName = request.getParameter("projectName");
		UserVO userVo = (UserVO) request.getSession().getAttribute("member"); 
		flag = projectService.createProject(projectName,userVo);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/main";
			if(request.getSession().getAttribute("project") != null) {
				viewName = "/project/viewProjectPage";
			}
		} 
		
		mav.setViewName(viewName);
		return mav;
	}
	
	//rest 팀명 체크
	@RequestMapping(value="/checkProjectName",method=RequestMethod.GET)
	public boolean checkUserIdPwd(@RequestParam("projectName") String projectName, HttpServletRequest request,HttpServletResponse response) throws Exception {
		boolean flag = false;
		flag = projectService.checkProjectName(projectName);
		return flag;
	}
}
