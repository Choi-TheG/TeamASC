package com.project.asc.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.project.asc.service.UserService;
import com.project.asc.vo.UserVO;

@RequestMapping("/user")
@RestController("userController")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/list",method=RequestMethod.GET)
	public ModelAndView selectUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		String viewName = "user";
		ArrayList<UserVO> list = userService.selectUser();
		mav.addObject("list",list);
		
		mav.setViewName(viewName);
		return mav;
	}
	
	@RequestMapping(value="/createUserPage",method=RequestMethod.GET)
	public ModelAndView createUserPage(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		String viewName = "createUser";
		
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/createUser",method=RequestMethod.POST)
	public ModelAndView createUser(@ModelAttribute("info") UserVO user, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		
		flag = userService.inserUser(user);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/user/list";
		} 
		mav.setViewName(viewName);
		
		return mav;
	}
	
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public ModelAndView deleteUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean flag = false;
		int seq = Integer.parseInt(request.getParameter("seq"));
		flag = userService.deleteUser(seq);
		String viewName = "error";
		if(flag) {
			viewName = "redirect:/user/list";
		} 
		mav.setViewName(viewName);
		
		return mav;
	}
	
	
	@RequestMapping(value="/checkId",method=RequestMethod.GET)
	public boolean checkUserId(@RequestParam("userId") String userId, HttpServletRequest request, 
			HttpServletResponse response) throws Exception {
		boolean flag = false;
		flag = userService.checkId(userId);
		return flag;
	}
}
