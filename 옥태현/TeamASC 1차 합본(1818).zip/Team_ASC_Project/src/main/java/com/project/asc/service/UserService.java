package com.project.asc.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.asc.dao.UserDAO;
import com.project.asc.vo.UserVO;

@Service("userService")
public class UserService {
	
	@Autowired
	private UserDAO userDAO;
	
	public ArrayList<UserVO> selectUser() {
		ArrayList<UserVO> list = null;
		
		list = userDAO.selectUser();
		
		return list;
	}
	
	public boolean inserUser(UserVO user) {
		boolean flag = false;
		
		flag = userDAO.InsertUser(user);
		
		return flag;
	}
	
	public boolean deleteUser(int seq) {
		boolean flag = false;
		
		flag = userDAO.deleteUser(seq);
		
		return flag;
	}
	
	public boolean checkId(String userId) {
		boolean flag = false;
		flag = userDAO.checkId(userId);
		return flag;
	}
	
	public boolean checkId(String userId,String userPwd) {
		boolean flag = false;
		flag = userDAO.checkId(userId,userPwd);
		return flag;
	}
	
	public UserVO selectUser(String id, String pwd) {
		UserVO user = new UserVO();
		user.setId(id);
		user.setPwd(pwd);
		UserVO vo = null;
		vo = userDAO.selectUser(user);
		return vo;
	}
	
	public String findId(UserVO user) {
		// TODO Auto-generated method stub
		String id = userDAO.findId(user);
		
		return id;
	}

	public String findPwd(UserVO user) {
		// TODO Auto-generated method stub
		String pwd = userDAO.findPwd(user);
		return pwd;
	}

	public String selectUserId(String userSeq) {
		// TODO Auto-generated method stub
		String userId = userDAO.selectUserId(userSeq);
		return userId;
	}

	public boolean updatePwd(UserVO user) {
		// TODO Auto-generated method stub
		boolean flag = userDAO.updatePwd(user);
		return flag;
	}
	
	/* 개인정보 수정 */
	public boolean updateMyInfo(UserVO user) {
		boolean flag = false;
		
		flag = userDAO.updateMyInfo(user);
		
		return flag;
	}
	
	/* 비밀번호 체크 */
	public UserVO selectUserPwd(String id,String pwd) {
		UserVO user = null;
		user = userDAO.selectUserPwd(id,pwd);
		
		return user;
	}
	
	/* 마이페이지 정보 */
	public UserVO selectMyInfo(String id) {
	
		UserVO user = null;
		user = userDAO.selectMyInfo(id);
		
//		System.out.println("service");
		return user;
		
	}
}
