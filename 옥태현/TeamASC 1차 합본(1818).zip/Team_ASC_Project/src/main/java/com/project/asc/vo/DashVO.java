package com.project.asc.vo;

import java.util.ArrayList;

public class DashVO {
	private ArrayList<DocVO> docList;
	
	public ArrayList<DocVO> getDocList(){
		return docList;
	}
	
	public void setDocList(ArrayList<DocVO> docList) {
		this.docList = docList;
	}
}
